/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package symulacjaodbioruodpadow;

/**
 *
 * @author piotr
 */
public class MyPoint
{
    int x;
    int y;

    public MyPoint(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    
}
